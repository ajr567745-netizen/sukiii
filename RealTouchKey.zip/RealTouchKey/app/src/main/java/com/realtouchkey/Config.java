package com.realtouchkey;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Data pemetaan: daftar tombol tap/hold + satu joystick (4 arah). Disimpan di SharedPreferences. */
public class Config {
    public static final int TAP = 0, HOLD = 1;

    public static class Mapping {
        public int key;
        public int type;
        public float x, y;

        public Mapping(int key, int type, float x, float y) {
            this.key = key;
            this.type = type;
            this.x = x;
            this.y = y;
        }
    }

    public final List<Mapping> maps = new ArrayList<>();
    public boolean hasJoy;
    public float jx, jy, jr = 130f;
    /** keyCode untuk atas, bawah, kiri, kanan (-1 = belum diatur) */
    public int[] jk = {-1, -1, -1, -1};

    public static Config load(Context c) {
        Config cf = new Config();
        try {
            String s = c.getSharedPreferences("rtk", Context.MODE_PRIVATE).getString("cfg", null);
            if (s == null) return cf;
            JSONObject o = new JSONObject(s);
            cf.hasJoy = o.optBoolean("hj", false);
            cf.jx = (float) o.optDouble("jx", 0);
            cf.jy = (float) o.optDouble("jy", 0);
            cf.jr = (float) o.optDouble("jr", 130);
            JSONArray k = o.optJSONArray("jk");
            if (k != null) for (int i = 0; i < 4; i++) cf.jk[i] = k.optInt(i, -1);
            JSONArray a = o.optJSONArray("maps");
            if (a != null) {
                for (int i = 0; i < a.length(); i++) {
                    JSONObject m = a.getJSONObject(i);
                    cf.maps.add(new Mapping(m.optInt("k", -1), m.optInt("t", TAP),
                            (float) m.optDouble("x", 0), (float) m.optDouble("y", 0)));
                }
            }
        } catch (Exception ignored) {
        }
        return cf;
    }

    public void save(Context c) {
        try {
            JSONObject o = new JSONObject();
            o.put("hj", hasJoy);
            o.put("jx", jx);
            o.put("jy", jy);
            o.put("jr", jr);
            JSONArray k = new JSONArray();
            for (int v : jk) k.put(v);
            o.put("jk", k);
            JSONArray a = new JSONArray();
            for (Mapping m : maps) {
                JSONObject j = new JSONObject();
                j.put("k", m.key);
                j.put("t", m.type);
                j.put("x", m.x);
                j.put("y", m.y);
                a.put(j);
            }
            o.put("maps", a);
            c.getSharedPreferences("rtk", Context.MODE_PRIVATE).edit().putString("cfg", o.toString()).apply();
        } catch (Exception ignored) {
        }
    }
}
