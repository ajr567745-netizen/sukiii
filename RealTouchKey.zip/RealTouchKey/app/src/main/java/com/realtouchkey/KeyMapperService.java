package com.realtouchkey;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.graphics.Path;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Menangkap tombol keyboard/gamepad (filter key event) lalu menerjemahkannya menjadi
 * gestur sentuh lewat dispatchGesture. Semua sentuhan aktif digabung dalam satu gestur
 * per siklus supaya multi-touch (joystick + tombol lain) bisa jalan bersamaan.
 */
public class KeyMapperService extends AccessibilityService {
    public static KeyMapperService instance;
    private static final int DUR = 80; // ms per segmen gestur

    private final Handler h = new Handler(Looper.getMainLooper());
    private WindowManager wm;
    private Config cfg = new Config();
    private boolean enabled = true;
    private LinearLayout bubble;
    private TextView toggleView;
    private Editor editor;

    private static class Touch {
        float x, y, tx, ty;
        boolean ending, sentFinal;
        GestureDescription.StrokeDescription last, pending;

        Touch(float x, float y, float tx, float ty, boolean ending) {
            this.x = x;
            this.y = y;
            this.tx = tx;
            this.ty = ty;
            this.ending = ending;
        }
    }

    private static final int JOY_ID = -1;
    private final Map<Integer, Touch> touches = new LinkedHashMap<>();
    private final boolean[] joyHeld = new boolean[4];
    private boolean busy;

    @Override
    protected void onServiceConnected() {
        instance = this;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        cfg = Config.load(this);
        showBubble();
    }

    @Override
    public boolean onUnbind(Intent intent) {
        if (editor != null) editor.close(false);
        if (bubble != null) {
            try {
                wm.removeView(bubble);
            } catch (Exception ignored) {
            }
            bubble = null;
        }
        instance = null;
        return super.onUnbind(intent);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
    }

    @Override
    public void onInterrupt() {
    }

    // ---------------------------------------------------------------- key handling

    @Override
    protected boolean onKeyEvent(KeyEvent e) {
        int code = e.getKeyCode();
        boolean down = e.getAction() == KeyEvent.ACTION_DOWN;

        if (editor != null) { // mode edit: tombol dipakai untuk mengikat penanda
            if (code == KeyEvent.KEYCODE_BACK) return false;
            if (down && e.getRepeatCount() == 0) editor.onKey(code);
            return true;
        }
        if (!enabled) return false;

        boolean first = down && e.getRepeatCount() == 0;
        boolean used = false;
        for (int i = 0; i < cfg.maps.size(); i++) {
            Config.Mapping m = cfg.maps.get(i);
            if (m.key != code) continue;
            used = true;
            if (first) pressMap(i, m);
            else if (!down) releaseMap(i, m);
        }
        if (cfg.hasJoy) {
            for (int d = 0; d < 4; d++) {
                if (cfg.jk[d] != code) continue;
                used = true;
                if (first) {
                    joyHeld[d] = true;
                    updateJoy();
                } else if (!down) {
                    joyHeld[d] = false;
                    updateJoy();
                }
            }
        }
        return used;
    }

    private void pressMap(int id, Config.Mapping m) {
        Touch t = touches.get(id);
        if (t != null) {
            if (m.type == Config.HOLD) t.ending = false;
            return;
        }
        touches.put(id, new Touch(m.x, m.y, m.x, m.y, m.type == Config.TAP));
        tick();
    }

    private void releaseMap(int id, Config.Mapping m) {
        if (m.type != Config.HOLD) return;
        Touch t = touches.get(id);
        if (t != null) t.ending = true;
        tick();
    }

    private void updateJoy() {
        float dx = 0, dy = 0;
        if (joyHeld[0]) dy -= 1;
        if (joyHeld[1]) dy += 1;
        if (joyHeld[2]) dx -= 1;
        if (joyHeld[3]) dx += 1;
        Touch t = touches.get(JOY_ID);
        if (dx == 0 && dy == 0) {
            if (t != null) t.ending = true;
        } else {
            float len = (float) Math.sqrt(dx * dx + dy * dy);
            float tx = cfg.jx + dx / len * cfg.jr;
            float ty = cfg.jy + dy / len * cfg.jr;
            if (t == null) {
                touches.put(JOY_ID, new Touch(cfg.jx, cfg.jy, tx, ty, false));
            } else {
                t.tx = tx;
                t.ty = ty;
                t.ending = false;
            }
        }
        tick();
    }

    // ---------------------------------------------------------------- gesture engine

    private void tick() {
        if (busy || touches.isEmpty()) return;
        GestureDescription.Builder b = new GestureDescription.Builder();
        int max = GestureDescription.getMaxStrokeCount();
        int n = 0;
        try {
            for (Touch t : touches.values()) {
                if (n >= max) break;
                Path p = new Path();
                p.moveTo(t.x, t.y);
                if (t.x != t.tx || t.y != t.ty) p.lineTo(t.tx, t.ty);
                GestureDescription.StrokeDescription s = (t.last == null)
                        ? new GestureDescription.StrokeDescription(p, 0, DUR, !t.ending)
                        : t.last.continueStroke(p, 0, DUR, !t.ending);
                t.pending = s;
                t.sentFinal = t.ending;
                b.addStroke(s);
                n++;
            }
            if (n == 0) return;
            busy = true;
            boolean ok = dispatchGesture(b.build(), new GestureResultCallback() {
                @Override
                public void onCompleted(GestureDescription g) {
                    busy = false;
                    Iterator<Touch> it = touches.values().iterator();
                    while (it.hasNext()) {
                        Touch t = it.next();
                        if (t.pending == null) continue;
                        if (t.sentFinal) {
                            it.remove();
                        } else {
                            t.last = t.pending;
                            t.x = t.tx;
                            t.y = t.ty;
                            t.pending = null;
                        }
                    }
                    tick();
                }

                @Override
                public void onCancelled(GestureDescription g) {
                    resetTouches();
                }
            }, h);
            if (!ok) resetTouches();
        } catch (Exception ex) {
            resetTouches();
        }
    }

    private void resetTouches() {
        busy = false;
        touches.clear();
        for (int i = 0; i < 4; i++) joyHeld[i] = false;
    }

    // ---------------------------------------------------------------- floating bubble

    private TextView pill(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(0xFFFFFFFF);
        v.setTextSize(12);
        v.setPadding(24, 14, 24, 14);
        return v;
    }

    private void showBubble() {
        bubble = new LinearLayout(this);
        bubble.setOrientation(LinearLayout.HORIZONTAL);
        bubble.setBackgroundColor(0xAA000000);

        TextView drag = pill("☰");
        toggleView = pill("RTK ON");
        TextView edit = pill("Edit");
        bubble.addView(drag);
        bubble.addView(toggleView);
        bubble.addView(edit);

        final WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = 0;
        lp.y = 0;

        drag.setOnTouchListener(new View.OnTouchListener() {
            float ox, oy;
            int sx, sy;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        ox = e.getRawX();
                        oy = e.getRawY();
                        sx = lp.x;
                        sy = lp.y;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        lp.x = sx + (int) (e.getRawX() - ox);
                        lp.y = sy + (int) (e.getRawY() - oy);
                        try {
                            wm.updateViewLayout(bubble, lp);
                        } catch (Exception ignored) {
                        }
                        return true;
                }
                return true;
            }
        });

        toggleView.setOnClickListener(v -> {
            enabled = !enabled;
            toggleView.setText(enabled ? "RTK ON" : "RTK OFF");
            toggleView.setTextColor(enabled ? 0xFFFFFFFF : 0xFFFF8A80);
            if (!enabled) {
                for (Touch t : touches.values()) t.ending = true;
                for (int i = 0; i < 4; i++) joyHeld[i] = false;
                tick();
            }
        });
        edit.setOnClickListener(v -> openEditor());

        wm.addView(bubble, lp);
    }

    // ---------------------------------------------------------------- editor hooks

    public void openEditor() {
        if (editor != null) return;
        for (Touch t : touches.values()) t.ending = true;
        tick();
        editor = new Editor(this, wm);
        if (bubble != null) bubble.setVisibility(View.GONE);
    }

    /** Dipanggil Editor saat ditutup. */
    void onEditorClosed() {
        editor = null;
        cfg = Config.load(this);
        if (bubble != null) bubble.setVisibility(View.VISIBLE);
    }
}
