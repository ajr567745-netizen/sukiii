package com.realtouchkey;

import android.content.Context;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Editor layar penuh (overlay aksesibilitas). Seret penanda ke posisi tombol di game,
 * pilih penanda, lalu tekan tombol keyboard untuk mengikatnya.
 */
class Editor {
    private final KeyMapperService svc;
    private final WindowManager wm;
    private final Config cfg;
    private final FrameLayout root;
    private final LinearLayout bar;
    private final TextView status;
    private final List<Marker> markers = new ArrayList<>();
    private final int[] rootLoc = new int[2];
    private final float density;
    private Marker selected;
    private Marker joyMarker;
    private int joyStep = 0;

    private class Marker extends TextView {
        Config.Mapping m; // null untuk joystick
        float offX, offY;

        Marker(Context c) {
            super(c);
        }

        boolean isJoy() {
            return m == null;
        }
    }

    Editor(KeyMapperService svc, WindowManager wm) {
        this.svc = svc;
        this.wm = wm;
        this.cfg = Config.load(svc);
        this.density = svc.getResources().getDisplayMetrics().density;

        root = new FrameLayout(svc);
        root.setBackgroundColor(0x66000000);

        bar = new LinearLayout(svc);
        bar.setOrientation(LinearLayout.VERTICAL);
        bar.setBackgroundColor(0xDD000000);

        LinearLayout row1 = row();
        row1.addView(btn("+Tap", v -> addTap(Config.TAP)));
        row1.addView(btn("+Tahan", v -> addTap(Config.HOLD)));
        row1.addView(btn("+Joy", v -> addJoy()));
        row1.addView(btn("Ubah tipe", v -> toggleType()));
        row1.addView(btn("Hapus", v -> deleteSelected()));

        LinearLayout row2 = row();
        row2.addView(btn("Joy R-", v -> resizeJoy(-20)));
        row2.addView(btn("Joy R+", v -> resizeJoy(20)));
        row2.addView(btn("Simpan", v -> close(true)));
        row2.addView(btn("Batal", v -> close(false)));

        status = new TextView(svc);
        status.setTextColor(0xFFFFFFFF);
        status.setTextSize(11);
        status.setPadding(16, 8, 16, 8);
        status.setText("Tambah penanda, seret ke tombol game, pilih, lalu tekan tombol keyboard.");

        bar.addView(row1);
        bar.addView(row2);
        bar.addView(status);

        for (Config.Mapping m : cfg.maps) addMarker(m);
        if (cfg.hasJoy) makeJoyMarker();
        root.addView(bar, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP));

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        wm.addView(root, lp);

        root.post(() -> {
            root.getLocationOnScreen(rootLoc);
            for (Marker mk : markers) place(mk);
        });
    }

    // ---------------------------------------------------------------- UI helpers

    private LinearLayout row() {
        LinearLayout l = new LinearLayout(svc);
        l.setOrientation(LinearLayout.HORIZONTAL);
        return l;
    }

    private Button btn(String text, View.OnClickListener l) {
        Button b = new Button(svc);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(11);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(4, 0, 4, 0);
        b.setOnClickListener(l);
        b.setLayoutParams(new LinearLayout.LayoutParams(0, dp(40), 1f));
        return b;
    }

    private int dp(float v) {
        return (int) (v * density);
    }

    static String keyName(int k) {
        if (k < 0) return "?";
        String s = KeyEvent.keyCodeToString(k);
        return s.startsWith("KEYCODE_") ? s.substring(8) : s;
    }

    private void refresh(Marker mk) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        if (mk.isJoy()) {
            g.setColor(0x554CAF50);
            mk.setText("JOY\n" + keyName(cfg.jk[0]) + " " + keyName(cfg.jk[1]) + " "
                    + keyName(cfg.jk[2]) + " " + keyName(cfg.jk[3]));
        } else {
            g.setColor(mk.m.type == Config.TAP ? 0xCC2196F3 : 0xCCFF9800);
            mk.setText(keyName(mk.m.key) + "\n" + (mk.m.type == Config.TAP ? "TAP" : "TAHAN"));
        }
        g.setStroke(mk == selected ? dp(3) : dp(1), mk == selected ? 0xFFFFFFFF : 0x88FFFFFF);
        mk.setBackground(g);
    }

    private void place(Marker mk) {
        float cx = mk.isJoy() ? cfg.jx : mk.m.x;
        float cy = mk.isJoy() ? cfg.jy : mk.m.y;
        ViewGroup.LayoutParams p = mk.getLayoutParams();
        mk.setX(cx - p.width / 2f - rootLoc[0]);
        mk.setY(cy - p.height / 2f - rootLoc[1]);
    }

    private void setupMarker(final Marker mk, int size) {
        mk.setGravity(Gravity.CENTER);
        mk.setTextColor(0xFFFFFFFF);
        mk.setTextSize(10);
        mk.setLayoutParams(new FrameLayout.LayoutParams(size, size));
        mk.setOnTouchListener((v, e) -> {
            int[] l = new int[2];
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    select(mk);
                    v.getLocationOnScreen(l);
                    mk.offX = e.getRawX() - l[0];
                    mk.offY = e.getRawY() - l[1];
                    return true;
                case MotionEvent.ACTION_MOVE:
                    v.getLocationOnScreen(l);
                    v.setX(v.getX() + (e.getRawX() - mk.offX - l[0]));
                    v.setY(v.getY() + (e.getRawY() - mk.offY - l[1]));
                    return true;
            }
            return true;
        });
        markers.add(mk);
        root.addView(mk);
        refresh(mk);
        bar.bringToFront();
    }

    private void addMarker(Config.Mapping m) {
        Marker mk = new Marker(svc);
        mk.m = m;
        setupMarker(mk, dp(52));
    }

    private void makeJoyMarker() {
        joyMarker = new Marker(svc);
        setupMarker(joyMarker, (int) (cfg.jr * 2));
    }

    private DisplayMetrics screen() {
        return svc.getResources().getDisplayMetrics();
    }

    private void select(Marker mk) {
        Marker old = selected;
        selected = mk;
        if (old != null) refresh(old);
        refresh(mk);
        if (mk.isJoy()) {
            joyStep = 0;
            status.setText("Joystick dipilih: tekan 4 tombol berurutan (atas, bawah, kiri, kanan).");
        } else {
            status.setText("Tekan tombol keyboard untuk mengikat penanda ini.");
        }
    }

    // ---------------------------------------------------------------- actions

    private void addTap(int type) {
        DisplayMetrics dm = screen();
        float off = markers.size() * 12f;
        Config.Mapping m = new Config.Mapping(-1, type, dm.widthPixels / 2f + off, dm.heightPixels / 2f + off);
        cfg.maps.add(m);
        addMarker(m);
        Marker mk = markers.get(markers.size() - 1);
        place(mk);
        select(mk);
    }

    private void addJoy() {
        if (joyMarker != null) {
            select(joyMarker);
            return;
        }
        DisplayMetrics dm = screen();
        cfg.hasJoy = true;
        cfg.jx = dm.widthPixels * 0.25f;
        cfg.jy = dm.heightPixels * 0.6f;
        makeJoyMarker();
        place(joyMarker);
        select(joyMarker);
    }

    private void resizeJoy(float delta) {
        if (joyMarker == null) return;
        int[] l = new int[2];
        joyMarker.getLocationOnScreen(l);
        float cx = l[0] + joyMarker.getWidth() / 2f;
        float cy = l[1] + joyMarker.getHeight() / 2f;
        cfg.jr = Math.max(60f, Math.min(300f, cfg.jr + delta));
        cfg.jx = cx;
        cfg.jy = cy;
        int size = (int) (cfg.jr * 2);
        joyMarker.setLayoutParams(new FrameLayout.LayoutParams(size, size));
        place(joyMarker);
    }

    private void toggleType() {
        if (selected == null || selected.isJoy()) return;
        selected.m.type = selected.m.type == Config.TAP ? Config.HOLD : Config.TAP;
        refresh(selected);
    }

    private void deleteSelected() {
        if (selected == null) return;
        Marker mk = selected;
        selected = null;
        root.removeView(mk);
        markers.remove(mk);
        if (mk.isJoy()) {
            cfg.hasJoy = false;
            joyMarker = null;
            cfg.jk = new int[]{-1, -1, -1, -1};
        } else {
            cfg.maps.remove(mk.m);
        }
        status.setText("Penanda dihapus.");
    }

    /** Dipanggil service saat tombol ditekan selama mode edit. */
    void onKey(int code) {
        if (selected == null) return;
        if (selected.isJoy()) {
            cfg.jk[joyStep] = code;
            joyStep = (joyStep + 1) % 4;
            String[] names = {"atas", "bawah", "kiri", "kanan"};
            status.setText("Joystick: berikutnya tombol untuk " + names[joyStep] + ".");
        } else {
            selected.m.key = code;
            status.setText("Terikat ke " + keyName(code) + ".");
        }
        refresh(selected);
    }

    void close(boolean save) {
        if (save) {
            for (Marker mk : markers) {
                int[] l = new int[2];
                mk.getLocationOnScreen(l);
                float cx = l[0] + mk.getWidth() / 2f;
                float cy = l[1] + mk.getHeight() / 2f;
                if (mk.isJoy()) {
                    cfg.jx = cx;
                    cfg.jy = cy;
                } else {
                    mk.m.x = cx;
                    mk.m.y = cy;
                }
            }
            // buang penanda yang belum diikat ke tombol
            for (int i = cfg.maps.size() - 1; i >= 0; i--) {
                if (cfg.maps.get(i).key < 0) cfg.maps.remove(i);
            }
            cfg.save(svc);
        }
        try {
            wm.removeView(root);
        } catch (Exception ignored) {
        }
        svc.onEditorClosed();
    }
}
