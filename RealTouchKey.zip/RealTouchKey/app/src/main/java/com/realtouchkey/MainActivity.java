package com.realtouchkey;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private TextView status;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(pad, pad * 2, pad, pad);

        TextView title = new TextView(this);
        title.setText("RealTouchKey");
        title.setTextSize(26);
        col.addView(title);

        status = new TextView(this);
        status.setTextSize(15);
        status.setPadding(0, pad / 2, 0, pad);
        col.addView(status);

        Button enable = new Button(this);
        enable.setText("1. Aktifkan layanan (Pengaturan Aksesibilitas)");
        enable.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        col.addView(enable);

        Button appInfo = new Button(this);
        appInfo.setText("Info aplikasi (untuk 'Izinkan setelan terbatas')");
        appInfo.setOnClickListener(v -> {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            i.setData(android.net.Uri.parse("package:" + getPackageName()));
            startActivity(i);
        });
        col.addView(appInfo);

        Button edit = new Button(this);
        edit.setText("2. Buka editor pemetaan");
        edit.setOnClickListener(v -> {
            if (KeyMapperService.instance == null) {
                Toast.makeText(this, "Layanan belum aktif.", Toast.LENGTH_LONG).show();
            } else {
                KeyMapperService.instance.openEditor();
            }
        });
        col.addView(edit);

        TextView help = new TextView(this);
        help.setTextSize(14);
        help.setPadding(0, pad, 0, 0);
        help.setText(
                "Cara pakai:\n"
              + "1. Tekan tombol 1, cari RealTouchKey di daftar, nyalakan.\n"
              + "   Di Android 13+ jika tombolnya abu-abu: buka Info aplikasi, menu titik tiga, "
              + "'Izinkan setelan terbatas', lalu ulangi.\n"
              + "2. Panel kecil RTK muncul di layar. Pindah ke game, tekan 'Edit'.\n"
              + "3. Tekan +Tap / +Tahan / +Joy, seret penanda ke posisi tombol di game, "
              + "pilih penanda, lalu tekan tombol di keyboard (OTG/Bluetooth) untuk mengikatnya.\n"
              + "   +Joy: tekan 4 tombol berurutan (atas, bawah, kiri, kanan), mis. W S A D.\n"
              + "4. Simpan. Tombol RTK ON/OFF di panel untuk menghidupkan atau mematikan pemetaan.\n\n"
              + "Catatan: arah kamera dengan gerakan mouse belum ada. Layanan aksesibilitas "
              + "tidak menerima gerakan mouse, hanya tombol.");
        col.addView(help);

        ScrollView sv = new ScrollView(this);
        sv.addView(col);
        setContentView(sv);
    }

    @Override
    protected void onResume() {
        super.onResume();
        boolean on = KeyMapperService.instance != null;
        status.setText(on ? "Layanan: AKTIF" : "Layanan: belum aktif");
        status.setTextColor(on ? 0xFF2E7D32 : 0xFFC62828);
    }
}
